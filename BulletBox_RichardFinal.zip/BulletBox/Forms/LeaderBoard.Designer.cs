﻿namespace BulletBox
{
    partial class LeaderBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.score10 = new System.Windows.Forms.Label();
            this.score9 = new System.Windows.Forms.Label();
            this.player10 = new System.Windows.Forms.Label();
            this.score8 = new System.Windows.Forms.Label();
            this.player9 = new System.Windows.Forms.Label();
            this.score7 = new System.Windows.Forms.Label();
            this.player8 = new System.Windows.Forms.Label();
            this.score6 = new System.Windows.Forms.Label();
            this.player7 = new System.Windows.Forms.Label();
            this.score5 = new System.Windows.Forms.Label();
            this.player6 = new System.Windows.Forms.Label();
            this.score4 = new System.Windows.Forms.Label();
            this.player5 = new System.Windows.Forms.Label();
            this.score3 = new System.Windows.Forms.Label();
            this.player4 = new System.Windows.Forms.Label();
            this.score2 = new System.Windows.Forms.Label();
            this.player3 = new System.Windows.Forms.Label();
            this.score1 = new System.Windows.Forms.Label();
            this.player2 = new System.Windows.Forms.Label();
            this.player1 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblMain = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(573, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 54);
            this.label1.TabIndex = 1;
            this.label1.Text = "Player";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(771, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 54);
            this.label2.TabIndex = 1;
            this.label2.Text = "Score";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(389, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 54);
            this.label3.TabIndex = 1;
            this.label3.Text = "Rank";
            // 
            // score10
            // 
            this.score10.AutoSize = true;
            this.score10.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.score10.ForeColor = System.Drawing.Color.White;
            this.score10.Location = new System.Drawing.Point(798, 587);
            this.score10.Name = "score10";
            this.score10.Size = new System.Drawing.Size(82, 37);
            this.score10.TabIndex = 1;
            this.score10.Text = "Score";
            this.score10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // score9
            // 
            this.score9.AutoSize = true;
            this.score9.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.score9.ForeColor = System.Drawing.Color.White;
            this.score9.Location = new System.Drawing.Point(798, 535);
            this.score9.Name = "score9";
            this.score9.Size = new System.Drawing.Size(82, 37);
            this.score9.TabIndex = 1;
            this.score9.Text = "Score";
            this.score9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // player10
            // 
            this.player10.AutoSize = true;
            this.player10.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.player10.ForeColor = System.Drawing.Color.White;
            this.player10.Location = new System.Drawing.Point(600, 587);
            this.player10.Name = "player10";
            this.player10.Size = new System.Drawing.Size(89, 37);
            this.player10.TabIndex = 1;
            this.player10.Text = "Player";
            // 
            // score8
            // 
            this.score8.AutoSize = true;
            this.score8.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.score8.ForeColor = System.Drawing.Color.White;
            this.score8.Location = new System.Drawing.Point(798, 483);
            this.score8.Name = "score8";
            this.score8.Size = new System.Drawing.Size(82, 37);
            this.score8.TabIndex = 1;
            this.score8.Text = "Score";
            this.score8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // player9
            // 
            this.player9.AutoSize = true;
            this.player9.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.player9.ForeColor = System.Drawing.Color.White;
            this.player9.Location = new System.Drawing.Point(600, 537);
            this.player9.Name = "player9";
            this.player9.Size = new System.Drawing.Size(89, 37);
            this.player9.TabIndex = 1;
            this.player9.Text = "Player";
            // 
            // score7
            // 
            this.score7.AutoSize = true;
            this.score7.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.score7.ForeColor = System.Drawing.Color.White;
            this.score7.Location = new System.Drawing.Point(798, 431);
            this.score7.Name = "score7";
            this.score7.Size = new System.Drawing.Size(82, 37);
            this.score7.TabIndex = 1;
            this.score7.Text = "Score";
            this.score7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // player8
            // 
            this.player8.AutoSize = true;
            this.player8.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.player8.ForeColor = System.Drawing.Color.White;
            this.player8.Location = new System.Drawing.Point(600, 483);
            this.player8.Name = "player8";
            this.player8.Size = new System.Drawing.Size(89, 37);
            this.player8.TabIndex = 1;
            this.player8.Text = "Player";
            // 
            // score6
            // 
            this.score6.AutoSize = true;
            this.score6.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.score6.ForeColor = System.Drawing.Color.White;
            this.score6.Location = new System.Drawing.Point(798, 379);
            this.score6.Name = "score6";
            this.score6.Size = new System.Drawing.Size(82, 37);
            this.score6.TabIndex = 1;
            this.score6.Text = "Score";
            this.score6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // player7
            // 
            this.player7.AutoSize = true;
            this.player7.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.player7.ForeColor = System.Drawing.Color.White;
            this.player7.Location = new System.Drawing.Point(600, 431);
            this.player7.Name = "player7";
            this.player7.Size = new System.Drawing.Size(89, 37);
            this.player7.TabIndex = 1;
            this.player7.Text = "Player";
            // 
            // score5
            // 
            this.score5.AutoSize = true;
            this.score5.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.score5.ForeColor = System.Drawing.Color.White;
            this.score5.Location = new System.Drawing.Point(798, 327);
            this.score5.Name = "score5";
            this.score5.Size = new System.Drawing.Size(82, 37);
            this.score5.TabIndex = 1;
            this.score5.Text = "Score";
            this.score5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // player6
            // 
            this.player6.AutoSize = true;
            this.player6.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.player6.ForeColor = System.Drawing.Color.White;
            this.player6.Location = new System.Drawing.Point(600, 379);
            this.player6.Name = "player6";
            this.player6.Size = new System.Drawing.Size(89, 37);
            this.player6.TabIndex = 1;
            this.player6.Text = "Player";
            // 
            // score4
            // 
            this.score4.AutoSize = true;
            this.score4.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.score4.ForeColor = System.Drawing.Color.White;
            this.score4.Location = new System.Drawing.Point(798, 275);
            this.score4.Name = "score4";
            this.score4.Size = new System.Drawing.Size(82, 37);
            this.score4.TabIndex = 1;
            this.score4.Text = "Score";
            this.score4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // player5
            // 
            this.player5.AutoSize = true;
            this.player5.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.player5.ForeColor = System.Drawing.Color.White;
            this.player5.Location = new System.Drawing.Point(600, 327);
            this.player5.Name = "player5";
            this.player5.Size = new System.Drawing.Size(89, 37);
            this.player5.TabIndex = 1;
            this.player5.Text = "Player";
            // 
            // score3
            // 
            this.score3.AutoSize = true;
            this.score3.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.score3.ForeColor = System.Drawing.Color.White;
            this.score3.Location = new System.Drawing.Point(798, 203);
            this.score3.Name = "score3";
            this.score3.Size = new System.Drawing.Size(104, 46);
            this.score3.TabIndex = 1;
            this.score3.Text = "Score";
            this.score3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // player4
            // 
            this.player4.AutoSize = true;
            this.player4.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.player4.ForeColor = System.Drawing.Color.White;
            this.player4.Location = new System.Drawing.Point(600, 275);
            this.player4.Name = "player4";
            this.player4.Size = new System.Drawing.Size(89, 37);
            this.player4.TabIndex = 1;
            this.player4.Text = "Player";
            // 
            // score2
            // 
            this.score2.AutoSize = true;
            this.score2.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.score2.ForeColor = System.Drawing.Color.White;
            this.score2.Location = new System.Drawing.Point(798, 151);
            this.score2.Name = "score2";
            this.score2.Size = new System.Drawing.Size(104, 46);
            this.score2.TabIndex = 1;
            this.score2.Text = "Score";
            this.score2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // player3
            // 
            this.player3.AutoSize = true;
            this.player3.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.player3.ForeColor = System.Drawing.Color.White;
            this.player3.Location = new System.Drawing.Point(590, 203);
            this.player3.Name = "player3";
            this.player3.Size = new System.Drawing.Size(110, 46);
            this.player3.TabIndex = 1;
            this.player3.Text = "Player";
            // 
            // score1
            // 
            this.score1.AutoSize = true;
            this.score1.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.score1.ForeColor = System.Drawing.Color.White;
            this.score1.Location = new System.Drawing.Point(798, 99);
            this.score1.Name = "score1";
            this.score1.Size = new System.Drawing.Size(104, 46);
            this.score1.TabIndex = 1;
            this.score1.Text = "Score";
            this.score1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // player2
            // 
            this.player2.AutoSize = true;
            this.player2.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.player2.ForeColor = System.Drawing.Color.White;
            this.player2.Location = new System.Drawing.Point(590, 151);
            this.player2.Name = "player2";
            this.player2.Size = new System.Drawing.Size(110, 46);
            this.player2.TabIndex = 1;
            this.player2.Text = "Player";
            // 
            // player1
            // 
            this.player1.AutoSize = true;
            this.player1.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.player1.ForeColor = System.Drawing.Color.White;
            this.player1.Location = new System.Drawing.Point(590, 99);
            this.player1.Name = "player1";
            this.player1.Size = new System.Drawing.Size(110, 46);
            this.player1.TabIndex = 1;
            this.player1.Text = "Player";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(412, 587);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(63, 37);
            this.label13.TabIndex = 1;
            this.label13.Text = "#10";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(416, 535);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(48, 37);
            this.label12.TabIndex = 1;
            this.label12.Text = "#9";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(416, 483);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 37);
            this.label11.TabIndex = 1;
            this.label11.Text = "#8";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(416, 431);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 37);
            this.label10.TabIndex = 1;
            this.label10.Text = "#7";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(416, 379);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 37);
            this.label9.TabIndex = 1;
            this.label9.Text = "#6";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(416, 327);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 37);
            this.label8.TabIndex = 1;
            this.label8.Text = "#5";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(416, 275);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 37);
            this.label7.TabIndex = 1;
            this.label7.Text = "#4";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.Maroon;
            this.label6.Location = new System.Drawing.Point(406, 203);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 46);
            this.label6.TabIndex = 1;
            this.label6.Text = "#3";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.Silver;
            this.label5.Location = new System.Drawing.Point(406, 151);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 46);
            this.label5.TabIndex = 1;
            this.label5.Text = "#2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.Gold;
            this.label4.Location = new System.Drawing.Point(406, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 46);
            this.label4.TabIndex = 1;
            this.label4.Text = "#1";
            // 
            // lblMain
            // 
            this.lblMain.BackColor = System.Drawing.Color.Transparent;
            this.lblMain.Font = new System.Drawing.Font("Segoe UI", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblMain.ForeColor = System.Drawing.Color.White;
            this.lblMain.Location = new System.Drawing.Point(981, 592);
            this.lblMain.Name = "lblMain";
            this.lblMain.Size = new System.Drawing.Size(280, 80);
            this.lblMain.TabIndex = 4;
            this.lblMain.Text = "MAIN MENU";
            this.lblMain.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblMain.Click += new System.EventHandler(this.lblMain_Click);
            this.lblMain.MouseEnter += new System.EventHandler(this.MouseEntered);
            this.lblMain.MouseLeave += new System.EventHandler(this.MouseLeft);
            // 
            // LeaderBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(30)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.lblMain);
            this.Controls.Add(this.score10);
            this.Controls.Add(this.score9);
            this.Controls.Add(this.player10);
            this.Controls.Add(this.score8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.player9);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.score7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.player8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.score6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.player7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.score5);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.player6);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.score4);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.player5);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.score3);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.player4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.score2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.player3);
            this.Controls.Add(this.player1);
            this.Controls.Add(this.score1);
            this.Controls.Add(this.player2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "LeaderBoard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BulletBox";
            this.Load += new System.EventHandler(this.LeaderBoard_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Label label1;
        private Label label2;
        private Label label3;
        private Label score10;
        private Label score9;
        private Label player10;
        private Label score8;
        private Label player9;
        private Label score7;
        private Label player8;
        private Label score6;
        private Label player7;
        private Label score5;
        private Label player6;
        private Label score4;
        private Label player5;
        private Label score3;
        private Label player4;
        private Label score2;
        private Label player3;
        private Label score1;
        private Label player2;
        private Label player1;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label lblMain;
    }
}